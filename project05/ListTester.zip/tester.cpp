/* tester.cpp
 * Joel Adams, for CS 112 at Calvin University.
 */
 
#include "ListTester.h"

int main() {
	ListTester lt;
	lt.runTests();
}